/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_360(unsigned x)
{
    return x + 2425393752U;
}

unsigned addval_393(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_122(unsigned x)
{
    return x + 2425393752U;
}

void setval_211(unsigned *p)
{
    *p = 3339274424U;
}

void setval_319(unsigned *p)
{
    *p = 2425378943U;
}

void setval_412(unsigned *p)
{
    *p = 1019435149U;
}

unsigned getval_439()
{
    return 3339274259U;
}

unsigned addval_338(unsigned x)
{
    return x + 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_297()
{
    return 2447411528U;
}

unsigned getval_249()
{
    return 3682912937U;
}

void setval_150(unsigned *p)
{
    *p = 3677407881U;
}

void setval_383(unsigned *p)
{
    *p = 3536115337U;
}

void setval_307(unsigned *p)
{
    *p = 3281049289U;
}

void setval_358(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_424()
{
    return 1506006669U;
}

void setval_246(unsigned *p)
{
    *p = 3224945032U;
}

void setval_345(unsigned *p)
{
    *p = 3676356873U;
}

unsigned addval_203(unsigned x)
{
    return x + 3682916041U;
}

unsigned addval_299(unsigned x)
{
    return x + 3372799625U;
}

unsigned getval_467()
{
    return 3229925769U;
}

unsigned addval_318(unsigned x)
{
    return x + 3372794249U;
}

unsigned getval_461()
{
    return 3682912905U;
}

void setval_479(unsigned *p)
{
    *p = 3267463497U;
}

unsigned addval_459(unsigned x)
{
    return x + 2446756297U;
}

void setval_279(unsigned *p)
{
    *p = 3383020169U;
}

unsigned addval_350(unsigned x)
{
    return x + 4257464715U;
}

unsigned getval_233()
{
    return 3286272328U;
}

unsigned addval_142(unsigned x)
{
    return x + 2430634312U;
}

void setval_130(unsigned *p)
{
    *p = 3281180297U;
}

void setval_224(unsigned *p)
{
    *p = 3286270280U;
}

unsigned addval_244(unsigned x)
{
    return x + 3531917961U;
}

void setval_322(unsigned *p)
{
    *p = 3348152713U;
}

unsigned getval_498()
{
    return 3680553609U;
}

unsigned addval_436(unsigned x)
{
    return x + 2445969691U;
}

void setval_401(unsigned *p)
{
    *p = 2430634440U;
}

unsigned addval_290(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_428(unsigned x)
{
    return x + 3269495112U;
}

void setval_204(unsigned *p)
{
    *p = 3526934937U;
}

unsigned addval_335(unsigned x)
{
    return x + 3378563721U;
}

unsigned addval_348(unsigned x)
{
    return x + 3281049225U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
