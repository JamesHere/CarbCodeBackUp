#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <cstdlib>
#include <stdlib.h>
#include "HashTable.h"

using namespace std;



int main(int argc, char* argv[]){
    int tableSize = atoi(argv[2]);
    char* filename = argv[1];

    HashTable cjj;
    //cjj.initial(tableSize);

    ifstream ifs;
    ifs.open(filename);
    string temp;
    getline(ifs,temp);
    int cnt = 0;
    int num=0;

/*
    string tableSize;
    cout<<"please enter the table size"<<endl;
    cin>>tableSize;
    */



    int yearID;
    string teamID;
    string leagueID;
    int playerID;
    int salary;
    string firstName;
    string lastName;
    int birthYear;
    string birthCountry;
    int weight;
    int height;
    string bats;
    string throws;
    string history="";

    while(getline(ifs,temp)){
        stringstream ss(temp);
        while(getline(ss, temp, ',')){
            if(cnt==13){
                cjj.addPlayer(yearID,teamID,leagueID,playerID,salary,
                firstName,lastName,birthYear,birthCountry,weight,height,
                bats,throws,history,tableSize);
                num++;
                history="";

                cnt=0;
            }
            if(cnt == 0){
                yearID = atoi(temp.c_str());
                history+=temp;
                history+=",";
            }else if(cnt == 1){
                teamID = temp;
                 history+=temp;
                history+=",";
            }else if(cnt == 2){
                leagueID = temp;
                 history+=temp;
                history+=",";
            }else if(cnt == 3){
                playerID = atoi(temp.c_str());
            }else if(cnt == 4){
                salary = atoi(temp.c_str());
                 history+=temp;
                history+=",";
            }else if(cnt == 5){
                firstName = temp;
            }else if(cnt == 6){
                lastName = temp;
            }else if(cnt == 7){
                birthYear = atoi(temp.c_str());
            }else if(cnt == 8){
                birthCountry = temp;
            }else if(cnt == 9){
                weight = atoi(temp.c_str());
            }else if(cnt == 10){
                height = atoi(temp.c_str());
            }else if(cnt == 11){
                bats = temp;
            }else if(cnt == 12){
                throws = temp;
            }

            cnt++;
        }
    }
    while(true){
        cout<<"====Main Menu===="<<endl;
        cout<<"1: Query hash table"<<endl;
        cout<<"2: Quit program"<<endl;
        string input;
        cin>>input;
        if(input == "1"){
    int chSearch = cjj.getChSearch();
    int openSearch = cjj.getOpenSearch();
    int chCnt = cjj.getChCnt();
    int openCnt = cjj.getOpenCnt();
    string last,first;
    cout<<"Please enter the first name"<<endl;
    cin>>first;
    cout<<"Please enter the last name"<<endl;
    cin>>last;

    cjj.display(first,last,tableSize);
    cjj.display2(first,last,tableSize);
    cout<<"Hash table size: "<<tableSize<<endl;
    cout<<"Collisions using chaining: "<<chCnt<<endl;
    cout<<"Collisions using open addressing: "<<openCnt<<endl;
    cout<<"Search operations using chaining: "<<chSearch<<endl;
    cout<<"Search operations using open addressing: "<<openSearch<<endl;

        }else if(input == "2"){
            cout<<"GoodBye!!!"<<endl;
            return 0;
        }else{
            cout<<"Please enter the correct input"<<endl;
        }

    }




}
