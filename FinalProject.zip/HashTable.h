#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Player{
    int yearID;
    string teamID;
    string leagueID;
    int playerID;
    int salary;
    string firstName;
    string lastName;
    int birthYear;
    string birthCountry;
    int weight;
    int height;
    string bats;
    string throws;
    vector <string> his;
    Player *next = NULL;

};


class HashTable{

public:
    HashTable();
    ~HashTable();
    //Player py;
    Player *py[5147];
    Player *py2[5147];
    void addPlayer(int,string,string,int,int,
    string,string,int,string,int,int,string,string,string,int);
    int hashSum(string,int);

    int openSolution(int index,int tableSize);
    int getOpenCnt();
    int getChSearch();
    int getChCnt();
    void display(string,string,int);
    void initial(int tableSize);
    int openSearch = 0;
    int getOpenSearch();
    void display2(string,string,int);


    int openCnt = 0;
    int chCnt = 0;
    int chSearch = 0;

};

//#include "FinalProject.cpp"
