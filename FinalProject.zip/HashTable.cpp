#include <iostream>
#include "HashTable.h"
#include <fstream>
#include <string>
#include <sstream>
#include <cstdlib>
#include <stdlib.h>
#include <vector>

using namespace std;

HashTable::HashTable(){



}

HashTable::~HashTable(){


}
///=============================================
void HashTable::initial(int tableSize){
     Player **py = new Player*[tableSize];
    for(int i=0;i<tableSize;i++){
        py[i] = NULL;
    }
    for(int i=0;i<tableSize+1;i++){
            cout<<i<<endl;
            //if(py[i]==NULL){
           // cout<<i<<": NULL"<<endl;
           // }
    }


}

///==============================================
void HashTable::display(string first,string last,int tableSize){
    string name = first;
    int flag = 0;
    name+=last;
    int index = hashSum(name,tableSize);
    if(py[index]->firstName==first and py[index]->lastName==last){
                flag = 1;
    }else{
    while(py[index]->next!=NULL){


        if(py[index]->next->firstName==first and py[index]->next->lastName==last){
            py[index] = py[index]->next;
            chSearch++;
            flag=1;
            break;
        }else{
            py[index] = py[index]->next;
            chSearch++;
        }
    }
    }

    if(flag==1){
        cout<<"First name: "<<first<<endl;
        cout<<"Last name: "<<last<<endl;
        cout<<"Year born: "<<py[index]->birthYear<<endl;
        cout<<"Country born: "<<py[index]->birthCountry<<endl;
        cout<<"Weight: "<<py[index]->weight<<endl;
        cout<<"Height: "<<py[index]->height<<endl;
        cout<<"Bats: "<<py[index]->bats<<endl;
        cout<<"Throws: "<<py[index]->throws<<endl;
        cout<<"Teams and salary"<<endl;
        for(int i=0;i<py[index]->his.size();i++){
            cout<<py[index]->his[i]<<endl;
        }
    }else{
        cout<<"Player not found"<<endl;
    }



}
void HashTable::display2(string first,string last,int tableSize){
    string name = first;
    int cnt = 0;
    name+=last;
    int index = hashSum(name,tableSize);
    if(py2[index]->firstName == first and py2[index]->lastName == last and py2[index]){
        openSearch++;
    }else{while(py2[index]->firstName != first and py2[index]->lastName != last and py2[index]){
        index = (index+1)/tableSize;
        cnt++;
        openSearch++;
        if(cnt == tableSize){
            cout<<"not found"<<endl;
            break;
        }
    }

    }

}



///===============================================
int HashTable::getOpenCnt(){
    return openCnt;

}

int HashTable::getChCnt(){
    return chCnt;

}
int HashTable::getChSearch(){
    return chSearch;
}
int HashTable::getOpenSearch(){
    return openSearch;
}




///================================================
int HashTable::hashSum(string key,int tableSize){
    int sum=0;
    for(int i=0;i<key.size();i++){
        sum+=key[i];
    }
    return sum%tableSize;

}
///=================================================
int HashTable::openSolution(int index,int tableSize){

    //cout<<"Collision! Using open addressing"<<endl;
    int temp = index;
    int cnt=0;
    while(py[temp]!=NULL){
            cnt++;
        openCnt++;
        temp = (temp+1)%tableSize;

        if(cnt == tableSize){
            break;
        }

    }

    //cout<<"Old index: "<<index<<endl;
    //cout<<"New index: "<<temp<<endl;
    return temp;

}


///================================================

void HashTable::addPlayer(int yearID,string teamID,string leagueID,int playerID,int salary,
string firstName,string lastName,int birthYear,string birthCountry,int weight,int height,
string bats,string throws,string history,int tableSize){

    string key = firstName;
    key+=lastName;
    int index = hashSum(key,tableSize);


    Player *n = new Player;
    vector <string> v;
    v.push_back(history);

    //if(py[index]!=NULL and py[index]->lastName == lastName and py[index]->firstName == firstName and py[index]->birthYear == birthYear){
      // py[index]->his.push_back(history);
    //}else{

        if(py[index]!=NULL){
                chCnt++;
        int flag = 0;
        Player *temp = py[index];
            if(temp->firstName==firstName and temp->lastName==lastName and temp->birthYear==birthYear){
                flag = 1;
            }else{
                while(temp->next!=NULL){
                    if(temp->next->firstName==firstName and temp->next->lastName==lastName and temp->height == height){
                        temp = temp->next;
                        flag=1;
                        break;
                    }else{
                        temp = temp->next;
                    }
                }
            }

        if(flag == 1){
            temp->his.push_back(history);
        }else{

        n->yearID =yearID;
        n->teamID =teamID;
        n->leagueID = leagueID;
        n->playerID = playerID;
        n->salary = salary;
        n->firstName = firstName;
        n->lastName = lastName;
        n->birthYear = birthYear;
        n->birthCountry = birthCountry;
        n->weight = weight;
        n->height = height;
        n->bats = bats;
        n->throws = throws;
        n->his = v;
        Player *temp = py[index];
        while(temp->next!=NULL){

            temp = temp->next;
        }
        temp->next = n;
        n->next =NULL;
        }

        }else{ //current == null

        n->yearID =yearID;
        n->teamID =teamID;
        n->leagueID = leagueID;
        n->playerID = playerID;
        n->salary = salary;
        n->firstName = firstName;
        n->lastName = lastName;
        n->birthYear = birthYear;
        n->birthCountry = birthCountry;
        n->weight = weight;
        n->height = height;
        n->bats = bats;
        n->throws = throws;
        n->his = v;

        py[index] = n;
        }

        ///==============================================
        if(py2[index]!=NULL and py2[index]->lastName == lastName and py2[index]->firstName == firstName and py2[index]->birthYear == birthYear){
        py2[index]->his.push_back(history);
        }else if(py2[index]!=NULL){
            index = openSolution(index,tableSize);
            n->yearID =yearID;
        n->teamID =teamID;
        n->leagueID = leagueID;
        n->playerID = playerID;
        n->salary = salary;
        n->firstName = firstName;
        n->lastName = lastName;
        n->birthYear = birthYear;
        n->birthCountry = birthCountry;
        n->weight = weight;
        n->height = height;
        n->bats = bats;
        n->throws = throws;
        n->his = v;

        py2[index] = n;

        }else{
           n->yearID =yearID;
        n->teamID =teamID;
        n->leagueID = leagueID;
        n->playerID = playerID;
        n->salary = salary;
        n->firstName = firstName;
        n->lastName = lastName;
        n->birthYear = birthYear;
        n->birthCountry = birthCountry;
        n->weight = weight;
        n->height = height;
        n->bats = bats;
        n->throws = throws;
        n->his = v;

        py2[index] = n;

        }

}
///==============================================
