#!/bin/bash

#Name:Chen KaKam


if [[ $# -ne 1 ]]
then
        echo "Usage: GradesAwk.sh filename"
else
	sort -k3,3 -k2 $1 | awk '{print int(($4+$5+$6)/3), "["$1"]",$3",",$2}'

fi