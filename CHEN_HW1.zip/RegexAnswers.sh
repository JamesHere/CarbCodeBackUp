#! /bin/bash

#Name:Chen KaKam

if [[ $# -ne 1 ]]
then
        echo "Usage: RegexAnswers.sh filename"
else 

        grep '[0-9]$' $* | wc -l

        grep '^[^aeiouAEIOU]' $* | wc -l

        egrep '^[A-Za-Z]{12}$' $* | wc -l

        grep  '^[0-9]\{3\}\-[0-9]\{3\}\-[0-9]\{4\}$' $* | wc -l

        grep '^303\-[0-9]\{3\}\-[0-9]\{4\}$' $* | wc -l

        grep '^[aeiouAEIOU]\w*[0-9]\b$' $* | wc -l

        grep 'geocities\.com$' $* | wc -l
        echo "0"
fi