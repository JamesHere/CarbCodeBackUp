/*  CHEN KAKAM
    CSCI-1310-104
    Instructor :C. Lambrocco
    Assignment-4



    Note:I fail in this assignment. I have no totally understand last assignment....
    I think the problem is I can't get the data normally, so the result will be a wired number
    I solve it for last assignment but I don't why it didn't work here and it make me feel annoying..
    At least I can make it completed;
    */
#include "WeatherForecaster.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

WeatherForecaster::WeatherForecaster()
{
    //ctor
    ifstream Fore;
    Fore.open("boulderData.txt");
    if (Fore.fail()){cout<<"Open failed"<<endl;}
    else{
        string weather;
        int lineIndex;
        while(getline(Fore,weather,'\n')){
            stringstream ss;
            ss<<weather;
            int weatherIndex = 0;
            while(getline(ss,weather,',')){
                if(weatherIndex == 0){
                    string day = yearData[lineIndex].day;
                    yearData[lineIndex].day = weather;
                }
                else if(weatherIndex == 1){
                    string ForecastDay = yearData[lineIndex].forecastDay;
                    yearData[lineIndex].forecastDay = weather;
                }
                else if(weatherIndex == 2){
                    istringstream convert(weather);//!!!
                    int highTemp = 0;
                    string strHighTemp = "";
                    strHighTemp = weather.substr(2,2);
                    if(!(istringstream(strHighTemp)>>highTemp)){
                        highTemp = 0;
                        yearData[lineIndex].highTemp = highTemp;
                    }

                }
                else if(weatherIndex == 3){
                    istringstream convert(weather);
                    int lowTemp = 0;
                    string strLowTemp = "";
                    strLowTemp = weather.substr(2,2);
                    if(!(!stringstream(strLowTemp)>>lowTemp)){
                        lowTemp = 0;
                        yearData[lineIndex].lowTemp = lowTemp;

                    }
                }
                else if(weatherIndex == 4){
                    istringstream convert(weather);
                    int humidity = 0;
                    if (!(istringstream(weather) >> humidity)){
                        humidity = 0;
                    }
                    yearData[lineIndex].humidity = humidity;
                }
                 else if(weatherIndex == 5){
                     istringstream convert(weather);
                     int avgWind = 0;
                     if (!(istringstream(weather) >> avgWind)){
                        avgWind = 0;
                     }
                     yearData[lineIndex].avgWind = avgWind;
                }
                else if(weatherIndex == 6){
                    yearData[lineIndex].avgWindDir = weather;
                }
                 else if(weatherIndex == 7){
                    istringstream covert(weather);
                    int maxWind = 0;
                    if(!(istringstream(weather)>>maxWind)){
                        maxWind = 0;
                    }
                    yearData[lineIndex].maxWind = maxWind;
                }
                 else if(weatherIndex == 8){
                    yearData[lineIndex].maxWindDir = weather;
                }
                 else if(weatherIndex == 9){
                    istringstream convert (weather);
                 double precip = 0.0;
                 if(!(istringstream(weather)>>precip)){
                    precip = 0.0;
                 }
                 yearData[lineIndex].precip = precip;

                }
                weatherIndex++;

            }
            lineIndex++;
        }
    }


}

WeatherForecaster::~WeatherForecaster()
{
    //dtor

}
void WeatherForecaster::printDaysInData(){
    for(int i=0;i<arrayLength;i++){
           // if(yearData[i].forecastDay == yearData[0].day){

        cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i].day<<">"<<endl;
        cout<<"H: <"<<yearData[i].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i].precip<<"> inches"<<endl;
        //}

    }
}


void WeatherForecaster::printForecastForDay(string date){
    for(int i=0;i<arrayLength;i++){
        if(date==yearData[i].day){
        cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i].day<<">"<<endl;
        cout<<"H: <"<<yearData[i].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i].precip<<"> inches"<<endl;
        }
    }

}
void WeatherForecaster::printFourDayForecast(string date){
    for(int i=0;i<arrayLength;i++){
        if(date == yearData[i].day){
        cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i].day<<">"<<endl;
        cout<<"H: <"<<yearData[i].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i].precip<<"> inches"<<endl;
                cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i].day<<">"<<endl;
        cout<<"H: <"<<yearData[i+1].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i+1].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i+1].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i+1].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i+1].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i+1].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i+1].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i+1].precip<<"> inches"<<endl;
                cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i+2].day<<">"<<endl;
        cout<<"H: <"<<yearData[i+2].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i+2].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i+2].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i+2].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i+2].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i+2].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i+2].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i+2].precip<<"> inches"<<endl;
                cout<<"========================"<<endl;
        cout<<"Forecast For "<<"<"<<yearData[i+3].day<<">"<<endl;
        cout<<"H: <"<<yearData[i+3].highTemp<<">"<<endl;
        cout<<"L: <"<<yearData[i+3].lowTemp<<">"<<endl;
        cout<<"Humidity: <"<<yearData[i+3].humidity<<">"<<endl;
        cout<<"Avg.wind: <"<<yearData[i+3].avgWind<<"> mph"<<endl;
        cout<<"Avg.wind Direction: <"<<yearData[i+3].avgWindDir<<">"<<endl;
        cout<<"Max Wind: <"<<yearData[i+3].maxWind<<"> mph"<<endl;
        cout<<"Max wind direction: <"<<yearData[i+3].maxWindDir<<">"<<endl;
        cout<<"Precipitation: <"<<yearData[i+3].precip<<"> inches"<<endl;

        }
    }
}

double WeatherForecaster::calculateTotalPrecipitation(){
    double sumOFPrecipitation;
    for(int i =0;i<arrayLength;i++){
        sumOFPrecipitation += yearData[i].precip;
    }
    cout<<"Total Precipitation: <"<<sumOFPrecipitation<<">"<<endl;
}

void WeatherForecaster::printLastDayItRained(){
    string lastRained;
    for(int i =0;i<arrayLength;i++){
        if(yearData[i].precip!=0.0){
            lastRained = yearData[i].day;
        }
    }
    cout<<"The last day it rained: <"<<lastRained<<">"<<endl;

}

void WeatherForecaster::printLastDayAboveTemperature(int date2){
    string lastHighTemp;
    for(int i =0;i<arrayLength;i++){
        if(date2 > yearData[i].highTemp){
            lastHighTemp = yearData[i].day;
        }
    }
    cout<<"The last day above the temperature: <"<<lastHighTemp<<">"<<endl;
}

void WeatherForecaster::printPredictedVsActualRainfall(int date2){
//fail
}

void WeatherForecaster::printTemperatureForecastDifference(string date){

//fail
}

string WeatherForecaster::getFirstDayInData(){
    return yearData[0].day;
}


string WeatherForecaster::getLastDayInData(){
    return yearData[arrayLength].day;
}
