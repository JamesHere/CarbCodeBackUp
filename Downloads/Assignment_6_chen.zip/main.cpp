/*  CHEN KAKAM
    CSCI-1310-104
    Instructor :C. Lambrocco
    Assignment-4



    Note:I fail in this assignment. I have no totally understand last assignment....
    I think the problem is I can't get the data normally, so the result will be a wired number
    I solve it for last assignment but I don't why it didn't work here and it make me feel annoying..
    At least I can make it completed;
    */
#include <iostream>
#include <string>
#include"WeatherForecaster.h"

using namespace std;

int main(){

    string date;
    WeatherForecaster yearData;
  /*  yearData.printDaysInData();

    cout<<"\n Enter a date (1):"<<endl;
    getline(cin,date);
    yearData.printForecastForDay(date);

    cout<<"\n Enter a data (2): "<<endl;
    getline(cin,date);
    yearData.printFourDayForecast(date);
    cin.get();
    yearData.calculateTotalPrecipitation();*/


}
