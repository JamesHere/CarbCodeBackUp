/*  CHEN KAKAM
    CSCI-1310-104
    Instructor :C. Lambrocco
    Assignment-4



    Note:I fail in this assignment. I have no totally understand last assignment....
    I think the problem is I can't get the data normally, so the result will be a wired number
    I solve it for last assignment but I don't why it didn't work here and it make me feel annoying..
    At least I can make it completed;
    */
#ifndef WEATHERFORECASTER_H
#define WEATHERFORECASTER_H

#include <iostream>

using namespace std;

struct ForecastDay{
    string day;
    string forecastDay;
    int highTemp;
    int lowTemp;
    int humidity;
    int avgWind;
    string avgWindDir;
    int maxWind;
    string maxWindDir;
    double precip;
};


class WeatherForecaster
{
    public:

       WeatherForecaster();
    ~WeatherForecaster();
    void addDayToData(ForecastDay);
    void printDaysInData();
    void printForecastForDay(string);
    void printFourDayForecast(string);
    double calculateTotalPrecipitation();
    void printLastDayItRained();
    void printLastDayAboveTemperature(int);
    void printTemperatureForecastDifference(std::string);
    void printPredictedVsActualRainfall(int);
    string getFirstDayInData();
    string getLastDayInData();

    protected:
    private:
        /*int arrayLength;
        int index;
        ForecastDay yearData[984]; //data for each day*/
        int arrayLength;
        int index;
        ForecastDay yearData[984];
};


#endif // WEATHERFORECASTER_H
